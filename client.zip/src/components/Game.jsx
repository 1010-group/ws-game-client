import React, { useEffect, useState } from "react";
import socket from "../socket";

const Game = () => {
  const [players, setPlayers] = useState({});
  const [playerId, setPlayerId] = useState(null);

  useEffect(() => {
    // Ulanish
    socket.on("connect", () => {
      console.log("Connected:", socket.id);
      setPlayerId(socket.id);

      socket.emit("joinGame", {
        id: socket.id,
        name: "Player_" + socket.id.slice(0, 4),
        position: { x: 0, y: 0 },
      });
    });

    // Boshqa player qo‘shildi
    socket.on("playerJoined", (player) => {
      setPlayers((prev) => ({ ...prev, [player.id]: player }));
    });

    // Boshqa player harakatlandi
    socket.on("playerMoved", ({ id, position }) => {
      setPlayers((prev) => ({
        ...prev,
        [id]: { ...prev[id], position },
      }));
    });

    // Boshqa player chiqdi
    socket.on("playerLeft", (id) => {
      setPlayers((prev) => {
        const updated = { ...prev };
        delete updated[id];
        return updated;
      });
    });

    return () => {
      socket.off("connect");
      socket.off("playerJoined");
      socket.off("playerMoved");
      socket.off("playerLeft");
    };
  }, []);

  // Harakat funksiyasi
  const move = (direction) => {
    const currentPlayer = players[playerId];
    if (!currentPlayer) return;

    const { x, y } = currentPlayer.position;
    let newPos = { x, y };

    if (direction === "up") newPos.y -= 10;
    if (direction === "down") newPos.y += 10;
    if (direction === "left") newPos.x -= 10;
    if (direction === "right") newPos.x += 10;

    socket.emit("move", { id: playerId, position: newPos });
  };

  return (
    <div>
      <div className="bg-red-400 p-4">
        <h1 className="text-2xl font-bold">Multiplayer Game</h1>
        <div className="flex gap-2 mt-2">
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded"
            onClick={() => move("up")}
          >
            ⬆️
          </button>
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded"
            onClick={() => move("down")}
          >
            ⬇️
          </button>
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded"
            onClick={() => move("left")}
          >
            ⬅️
          </button>
          <button
            className="px-4 py-2 bg-blue-500 text-white rounded"
            onClick={() => move("right")}
          >
            ➡️
          </button>
        </div>
      </div>

      <div
        style={{ position: "relative", height: "500px", border: "1px solid black" }}
        className="mt-4"
      >
        {Object.entries(players).map(([id, player]) => (
          <div
            key={id}
            style={{
              position: "absolute",
              left: `${player.position.x}px`,
              top: `${player.position.y}px`,
              width: "20px",
              height: "20px",
              backgroundColor: "red",
              borderRadius: "50%",
            }}
            title={player.name}
          ></div>
        ))}
      </div>
    </div>
  );
};

export default Game;